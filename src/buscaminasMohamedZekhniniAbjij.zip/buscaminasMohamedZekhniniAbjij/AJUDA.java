package buscaminasMohamedZekhniniAbjij;

public class AJUDA {

    public static void main(String[] args) throws InterruptedException {
        System.out.println(
        		  "                 .               \r\n"
                + "                 .               \r\n"
                + "                 .       :       \r\n"
                + "                 :      .        \r\n"
                + "        :..   :  : :  .          \r\n"
                + "           ..  ; :: .            \r\n"
                + "              ... .. :..         \r\n"
                + "             ::: :...            \r\n"
                + "         ::.:.:...;; .....       \r\n"
                + "      :..     .;.. :;     ..     \r\n"
                + "            . :. .  ;.           \r\n"
                + "             .: ;;: ;.           \r\n"
                + "            :; .BRRRV;           \r\n"
                + "               YB BMMMBR         \r\n"
                + "              ;BVIMMMMMt         \r\n"
                + "        .=YRBBBMMMMMMMB          \r\n"
                + "      =RMMMMMMMMMMMMMM;          \r\n"
                + "    ;BMMR=VMMMMMMMMMMMV.         \r\n"
                + "   tMMR::VMMMMMMMMMMMMMB:        \r\n"
                + "  tMMt ;BMMMMMMMMMMMMMMMB.       \r\n"
                + " ;MMY ;MMMMMMMMMMMMMMMMMMV       \r\n"
                + " XMB .BMMMMMMMMMMMMMMMMMMM:      \r\n"
                + " BMI +MMMMMMMMMMMMMMMMMMMMi      \r\n"
                + ".MM= XMMMMMMMMMMMMMMMMMMMMY      \r\n"
                + " BMt YMMMMMMMMMMMMMMMMMMMMi      \r\n"
                + " VMB +MMMMMMMMMMMMMMMMMMMM:      \r\n"
                + " ;MM+ BMMMMMMMMMMMMMMMMMMR       \r\n"
                + "  tMBVBMMMMMMMMMMMMMMMMMB.       \r\n"
                + "   tMMMMMMMMMMMMMMMMMMMB:        \r\n"
                + "    ;BMMMMMMMMMMMMMMMMY          \r\n"
                + "      +BMMMMMMMMMMMBY:           \r\n"
                + "        :+YRBBBRVt;");
        
        Thread.sleep(1500);
        System.out.println();

        // Mensaje de bienvenida y presentación del menú
        System.out.println("Benvingut al Buscamines!\n"
                + "\n1. Escull el teu nivell de dificultat (també pots personalitzar el tauler segons la teva preferència)");
        Thread.sleep(4000);
        System.out.println("\n2. Comença a jugar:");
        System.out.println();
        
        // Instrucciones del juego
        System.out.println("L'objectiu del Buscamines és destapar totes les caselles sense trobar cap mina.");
        Thread.sleep(6000);
        System.out.println("A mesura que seleccionis caselles, apareixerà el número de mines que hi ha als voltants.");
        System.out.println();
        
        // Información sobre el ranking y la puntuación
        System.out.println("També pots consultar el teu ranking i la teva puntuació!");
        System.out.println("Gaudix del Buscamines i molta sort!");
    }
}
